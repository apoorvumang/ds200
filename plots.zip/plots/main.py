import matplotlib.pyplot as plt
import numpy as np
import json
from collections import defaultdict
import csv
        
reader = csv.DictReader(open("data/sex_ratio.csv"))
data = []
for raw in reader:
    data.append(raw)


for i, d in enumerate(data):
    data[i]['sex_ratio'] = int(d['sex_ratio'])
    data[i]['goal'] = int(d['goal'])


def scoring_func(x):
    return x['sex_ratio']

sorted_data = sorted(data, key = scoring_func) 


worst_10 = sorted_data[:10]
states = []
sex_ratios = []
for w in worst_10:
    states.append(w['State'])
    sex_ratios.append(w['sex_ratio'])

x = np.arange(len(states))


fig, ax = plt.subplots(figsize=(15, 5))
ax.set_ylim([700, 1000])
plt.title('Top 10 worst sex ratios by state (2001)')

plt.bar(x, sex_ratios)
plt.xticks(x, states)
plt.show()

f = open('data/literacy.json', 'r')
data = f.read()
x = json.loads(data)
keys = ['1981', '1991', '2001', '2011']
data = defaultdict(list)
for t in x['data']:
    for id in range(-(len(keys)), 0):
        k = keys[id]
        if t[id] != 'NA':
            d = float(t[id])
        data[k].append(d)

box_plot_data=[]
labels = []
for key, value in data.items():
    box_plot_data.append(value)
    labels.append(key)
plt.boxplot(box_plot_data, labels=labels)
plt.title('Literacy rate spread across states in India')
plt.show()

f = open('data/fdi.json', 'r')
data = f.read()
x = json.loads(data)
data = []
for d in x['data']:
    data.append(d[1:])
total_data = []
for i in range(len(data[0])):
    total_data.append(0)

for d in data:
    for i, y in enumerate(d):
        total_data[i] += float(y)
keys = []
for k in x['fields']:
    if k['id'] != 'a':
        keys.append(k['label'])


plt.figure(figsize=(15,5))
plt.title('Total FDI Equity Inflows in India, 2001-2017')
plt.plot(keys, total_data, 'ro')
plt.show()
